---
name: Feature
about: 개발할 기능에 대해 서술합니다.
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## 🚀 Feature
<!-- 제안하는 기능에 대해서 간결하고 명확하게 설명해주세요.-->

## Motivation
<!-- 제안하는 기능의 필요성과 동시에 대해서 서술해주세요. 제안하는 기능이 GitHub 관련 이슈와 같이 다른 문제여도 좋습니다. -->

## Pitch
<!-- 어떻게 구현할지 간략하게 설명해주세요. -->

## Additional context
<!-- 추가적인 정보가 있다면 서술해주세요.-->
